#include <signal.h>
#include <time.h>
#include <signal.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "client.h"
#include "main.h"

char udp_message[128];
pthread_mutex_t udp_message_mutex;

struct udp_conn conn;

#define REFERENCE 1
#define KP 10
#define KI 800

int main(){

	signal(SIGINT, sighandler);

	if (pthread_mutex_init(&udp_message_mutex, NULL) != 0){
		perror("mutex initilization error");
		exit(1);
	}

	if (udp_init_client(&conn, 9999, "192.168.0.1")) {
		printf("init failed\n");
		exit(1);
	}
	char *msg = "START";
	if (udp_send(&conn, msg, sizeof(msg)+1) == -1) {
		printf("send failed\n");
		exit(1);
	}
	printf("Simulator started\n");

	pthread_t udp_thread;
	pthread_create(&udp_thread,NULL,(void*)udp_listen,NULL);


	pthread_t controller_thread;
	pthread_create(&controller_thread,NULL,(void*)controller,NULL);

	struct timespec time;
	clock_gettime(CLOCK_REALTIME, &time);
	timespec_add_us(&time, 495000);
	clock_nanosleep(&time);

	udp_send(&conn, "STOP", 5);
	udp_close(&conn);
	return 0;
}


void sighandler(int signum){
	printf("exiting, closing simulator and udp connection..\n");
	char* msg = "STOP";
	udp_send(&conn, msg, strlen(msg)+1);
	udp_close(&conn);
	exit(1);

}

void *udp_listen(void){
	char *GET = "GET";

	while(1){
		if (udp_send(&conn, GET, sizeof(GET)) == -1) {
			printf("send failed\n");
			exit(1);
		}
		pthread_mutex_lock(&udp_message_mutex);
		if (udp_receive(&conn,udp_message,sizeof(udp_message))==-1){
			printf("receive failed\n");
			exit(1);
		}
		pthread_mutex_unlock(&udp_message_mutex);

	}
	return NULL;
}

void *controller(){
	float y;
	char m[128];
	struct timespec time;
	double error;
	double integral = 0;
	double u;
	double period = 0.005;

	char msg[128];
	while(1){

		clock_gettime(CLOCK_REALTIME, &time);
		timespec_add_us(&time, period*1000000);
		clock_nanosleep(&time);
		pthread_mutex_lock(&udp_message_mutex);
		memcpy(m,&udp_message[8],7);
		m[7] = '\0';
		y = atof(m);
		pthread_mutex_unlock(&udp_message_mutex);

		error = REFERENCE - y;
		integral += error*period;
		u = KP * error + KI * integral;

		sprintf(msg,"SET:%3.3f", u);

		if (udp_send(&conn, msg, sizeof(msg)+1) == -1) {
			printf("send controller failed\n");
			exit(1);
		}
	}

	return NULL;
}
