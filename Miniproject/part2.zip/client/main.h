/*
 * main.h
 *
 *  Created on: Nov 18, 2016
 *      Author: student
 */

#ifndef MAIN_H_
#define MAIN_H_


//Close the simulator and UDP port before exiting with CTRL+C
void sighandler(int signum);

//Continously listen to UDP for process y value and SIGNAL
void *udp_listen(void);

//Replies to signal if signal_flag is high
void *signal_reply();

//Continously sends get message to server
void *get();

//reads controller_setpoint, calculates new u value and sends it to server
void *controller();


#endif /* MAIN_H_ */
