#include "client.h"
#include <signal.h>
#include <time.h>
#include <signal.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "main.h"

float system_measurement;
int signal_flag = 1;
pthread_mutex_t signal_flag_mutex;
pthread_mutex_t system_measurement_mutex;
pthread_mutex_t udp_send_mutex;

struct udp_conn conn;

#define REFERENCE 1
#define KP 10
#define KI 800

int main(){

	signal(SIGINT, sighandler);

	if (pthread_mutex_init(&signal_flag_mutex, NULL) != 0){
		perror("mutex initilization error");
		exit(1);
	}
	if (pthread_mutex_init(&system_measurement_mutex, NULL) != 0){
		perror("mutex initilization error");
		exit(1);
	}
	if (pthread_mutex_init(&udp_send_mutex, NULL) != 0){
			perror("mutex initilization error");
			exit(1);
		}

	if (udp_init_client(&conn, 9999, "192.168.0.1")) {
		printf("init failed\n");
		exit(1);
	}
	char *msg = "START";
	if (udp_send(&conn, msg, sizeof(msg)+1) == -1) {
		printf("send failed\n");
		exit(1);
	}
	printf("Simulator started\n");

	pthread_t udp_thread;
	pthread_create(&udp_thread,NULL,(void*)udp_listen,NULL);

	pthread_t get_thread;
	pthread_create(&get_thread,NULL,(void*)get,NULL);

	pthread_t signal_thread;
	pthread_create(&signal_thread,NULL,(void*)signal_reply,NULL);

	pthread_t controller_thread;
	pthread_create(&controller_thread,NULL,(void*)controller,NULL);

	struct timespec time;
	clock_gettime(CLOCK_REALTIME, &time);
	timespec_add_us(&time, 490000);

	clock_nanosleep(&time);

	udp_send(&conn, "STOP", 5);
	udp_close(&conn);
	return 0;
}


void sighandler(int signum){ //Close the simulator and UDP port before exiting with CTRL+C
	printf("exiting, closing simulator and udp connection..\n");
	char* msg = "STOP";
	udp_send(&conn, msg, strlen(msg)+1);
	udp_close(&conn);
	exit(1);
}

void *udp_listen(void){
	char udp_buffer[128];
	char m[128];

	while(1){
		if (udp_receive(&conn,udp_buffer,sizeof(udp_buffer))==-1){
			printf("receive failed\n");
			exit(1);
		}
		if(!strncmp(udp_buffer, "SIGNAL", 6)){
			pthread_mutex_lock(&signal_flag_mutex);
			signal_flag = 1;
			pthread_mutex_unlock(&signal_flag_mutex);
		}

		else if(!strncmp(udp_buffer, "GET_ACK", 7)){

			memcpy(m,&udp_buffer[8],7);
			m[7] = '\0';
			pthread_mutex_lock(&system_measurement_mutex);
			system_measurement = atof(m);
			pthread_mutex_unlock(&system_measurement_mutex);
		}
	}
	return NULL;
}

void *signal_reply(){
	char *ACK = "SIGNAL_ACK";

	while(1){
		pthread_mutex_lock(&signal_flag_mutex);
		if (signal_flag){
			pthread_mutex_lock(&udp_send_mutex);
			if (udp_send(&conn, ACK, 11) == -1) {
				printf("send ack failed\n");
				exit(1);
			}
			pthread_mutex_unlock(&udp_send_mutex);
			signal_flag = 0;
		}
		pthread_mutex_unlock(&signal_flag_mutex);
	}
	return NULL;
}

void *get(){
	char *GET = "GET";
	struct timespec time;

	while(1){
		pthread_mutex_lock(&udp_send_mutex);
		if (udp_send(&conn, GET, 4) == -1) {
			printf("send GET failed\n");
			exit(1);
		}
		pthread_mutex_unlock(&udp_send_mutex);
		clock_gettime(CLOCK_REALTIME, &time);
		timespec_add_us(&time, 100);
		clock_nanosleep(&time);
	}
	return NULL;
}

void *controller(){
	struct timespec time;
	double error;
	double integral = 0;
	double u;
	double period = 0.005;

	char msg[128];
	while(1){

		clock_gettime(CLOCK_REALTIME, &time);
		timespec_add_us(&time, period*1000000);
		clock_nanosleep(&time);

		pthread_mutex_lock(&system_measurement_mutex);
		error = REFERENCE - system_measurement;
		pthread_mutex_unlock(&system_measurement_mutex);
		integral += error*period;
		u = KP * error + KI * integral;

		sprintf(msg,"SET:%3.3f", u);
		pthread_mutex_lock(&udp_send_mutex);
		if (udp_send(&conn, msg, sizeof(msg)+1) == -1) {
			printf("send controller failed\n");
			exit(1);
		}
		pthread_mutex_unlock(&udp_send_mutex);
	}
	return NULL;
}
